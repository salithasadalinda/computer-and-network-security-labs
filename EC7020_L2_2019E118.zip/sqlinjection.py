#!/usr/bin/python
import sqlite3

# Create or connect to the database
conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

def search_user(email, password):
    cursor.execute("SELECT * FROM Users WHERE EMAIL = ? AND PASSWORD = ?", (email, password))# not much vulnarable 
    # query = f"SELECT * FROM Users WHERE EMAIL = '{email}' AND PASSWORD = '{password}'"#vulnarability
    # cursor.execute(query)
    user = cursor.fetchone()
    return user

while True:
    print("Enter your email and password to search for a user.")
    email = input("Email: ")
    password = input("Password: ")

    user = search_user(email, password)

    if user:
        print("User found:")
        print(f"ID: {user[0]}")
        print(f"Email: {user[1]}")
        print(f"Password: {user[2]}")
        print(f"Secret: {user[3]}")
    else:
        print("User not found. Please try again.")

    choice = input("Do you want to search for another user? (yes/no): ")
    if choice.lower() != 'yes':
        break

# Close the connection
conn.close()
