#!/usr/bin/python
import sqlite3

# Create or connect to the database
conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

# Create the table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Users 
    (
        ID INTEGER PRIMARY KEY AUTOINCREMENT,
        EMAIL TEXT NOT NULL,
        PASSWORD TEXT NOT NULL,
        SECRET TEXT NOT NULL
    );
''')

# Define the data to be inserted
data_to_insert = [
    (1, 'user1@example.com', 'password1', 'secret1'),
    (2, 'user2@example.com', 'password2', 'secret2'),
    (3, 'user3@example.com', 'password3', 'secret3'),
    # Add more rows as needed
]

# Insert the manual data
cursor.executemany("INSERT INTO Users (ID, EMAIL, PASSWORD, SECRET) VALUES (?, ?, ?, ?)", data_to_insert)

# Commit the changes and close the connection
conn.commit()
conn.close()

print("Manual data inserted successfully")
