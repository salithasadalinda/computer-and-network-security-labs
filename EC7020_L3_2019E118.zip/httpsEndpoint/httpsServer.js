const https = require('https');
const fs = require('fs');
const url = require('url');
const querystring = require('querystring');
const express=require("express");

const options = {
    key: fs.readFileSync('secure/private-key.pem'),
    cert: fs.readFileSync('secure/certificate.pem')
};
const server = https.createServer(options, (req, res) => {
    if (req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const parsedBody = querystring.parse(body);
            if (parsedBody.username === 'sadalinda' && parsedBody.password === 'pwd1234') {
                res.statusCode = 200;
                res.setHeader('Content-Type', 'text/plain');
                res.end('Login successful\n');
            } else {
                res.statusCode = 401;
                res.setHeader('Content-Type', 'text/plain');
                res.end('Invalid username or password\n');
            }
        });
    } else {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end('Please use a POST request to login\n');
    }
});

server.listen(3001, '127.0.0.1', () => {
    console.log('Server running at https://127.0.0.1:3001/');
});
