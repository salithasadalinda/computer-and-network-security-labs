import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;

public class RSAEncryption {

    private static final int MAX_LENGTH = 2048;
    private BigInteger p; // First prime number
    private BigInteger q; // Second prime number
    private BigInteger n; // Modulus for public and private keys
    private BigInteger phi; // Euler's totient function (phi)
    private BigInteger e; // Public exponent
    private BigInteger d; // Private exponent
    private Random random;

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_BLUE = "\u001B[34m";

    public RSAEncryption() {
        random = new Random();
        p = BigInteger.probablePrime(MAX_LENGTH, random); // Generated prime number p
        q = BigInteger.probablePrime(MAX_LENGTH, random); // Generated prime number q
        n = p.multiply(q); // n = p * q which is used as the modulus for both the public and
                           // private keys
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE)); // Compute phi = (p-1)(q-1)
        e = BigInteger.probablePrime(MAX_LENGTH / 2, random); // an integer e such that 1 < e < phi(n) and gcd(e,
                                                              // phi(n)) = 1

        // Ensure that e is coprime to phi(n)
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0) {
            e = e.add(BigInteger.ONE);
        }

        d = e.modInverse(phi); // Compute d, the modular multiplicative inverse of e (mod phi(n))
        printKeys();
    }

    private void printKeys() {
        System.out.println(ANSI_GREEN + "public key value Pair : \n{" + n + " , " + e + " }" + ANSI_RESET);
        System.out.println(ANSI_RED + "private key value Pair : \n{" + n + " , " + d + " }" + ANSI_RESET);
    }

    public byte[] encryptMessage(byte[] message) {
        // Encryption: c = m^e mod n
        return (new BigInteger(message)).modPow(e, n).toByteArray();
    }

    public byte[] decryptMessage(byte[] message) {
        // Decryption: m = c^d mod n
        return (new BigInteger(message)).modPow(d, n).toByteArray();
    }

    private static String bytesToString(byte[] cipher) {
        StringBuilder temp = new StringBuilder();
        for (byte b : cipher) {
            temp.append(Byte.toString(b));
        }
        return temp.toString();
    }

    public static void main(String[] arguments) {
        Scanner scanner = new Scanner(System.in); // Create a Scanner object
        RSAEncryption rsa = new RSAEncryption();
        System.out.println("Enter message: " + ANSI_RESET); // Prompt the user
        String inputString = scanner.nextLine(); // Read user input
        byte[] cipher = rsa.encryptMessage(inputString.getBytes());
        byte[] plain = rsa.decryptMessage(cipher);
        System.out.println(ANSI_BLUE + "Encrypting Bytes: \n" + bytesToString(cipher) + ANSI_RESET);
        System.out.println(ANSI_RED + "cyper text: \n" + new String(cipher) + ANSI_RESET);
        System.out.println(ANSI_BLUE + "Decrypting Bytes: \n" + bytesToString(plain) + ANSI_RESET);
        System.out.println("Message : \n" + new String(plain));
        scanner.close();
    }
}
